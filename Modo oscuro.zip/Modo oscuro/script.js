const btn = document.getElementById('theme-toggle');

btn.addEventListener('click', () => {
    // Intercambia la clase en el body
    document.body.classList.toggle('dark-mode');

    // Cambia el texto del botón según el modo
    if (document.body.classList.contains('dark-mode')) {
        btn.textContent = "Modo Claro ☀️";
    } else {
        btn.textContent = "Modo Oscuro 🌙";
    }
});